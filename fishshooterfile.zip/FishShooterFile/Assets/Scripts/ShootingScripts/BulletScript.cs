﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletScript : MonoBehaviour {

	public static BulletScript instance;
	private Rigidbody2D rigidBody;
	public float bulletSpeed;

	void Awake () {
		rigidBody = GetComponent<Rigidbody2D> ();
	}

	void Start () {
		rigidBody.velocity = transform.right * bulletSpeed;
	}

	void OnTriggerEnter2D (Collider2D target) {
		if (target.tag == "MasterEnemy1") {
            EnemyDamage();
			Debug.Log ("Enemy Hit!!!!");
			Destroy (gameObject);
		}
	}

    void EnemyDamage() {
        PlayerShootScript.instance.AttackDamage();
    }
}
