﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerHealthSpawn : MonoBehaviour {

	public GameObject health;

	private float timeToSpawn = 10f;
	private float timeToSpawnNext = 20f; 

	void Start () {
		
	}

	void Update () {
		if(Time.time >= timeToSpawn) {
			SpawnHealth ();
			timeToSpawn = Time.time + timeToSpawnNext;
		}
	}

	void SpawnHealth () {
		Vector3 spawnHealth = new Vector3 (Random.Range(-2f, 0f), Random.Range(-2f, 3f), transform.position.z);
		transform.position = spawnHealth;
		GameObject.Instantiate (health, spawnHealth, transform.rotation);
	}
}
