﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HealthScript : MonoBehaviour {

	public static HealthScript instance;

	public GameObject player;
	public int plusHealth = 10;
	public PlayerHealthScript playerHealth;

   
	void Start () {
		playerHealth = player.GetComponent<PlayerHealthScript> ();
		MakeInstance ();
	}
	
	void MakeInstance () {
		if (instance == null) {
			instance = this;
		}
	}

	void OnTriggerEnter2D(Collider2D target) {
		if (target.tag == "Player") {
			PlayerHealthScript.instance.AddHealth (plusHealth);
    		Destroy (gameObject);
			Debug.Log ("Plus Health + 10%");

		}
	}
}
















