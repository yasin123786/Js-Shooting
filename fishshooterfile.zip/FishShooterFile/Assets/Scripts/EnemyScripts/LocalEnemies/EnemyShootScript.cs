﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyShootScript : MonoBehaviour {
	
	public static EnemyShootScript instance;
	public GameObject enemyBullet;
	private float timeToShoot = 0.5f;
	private float timeToShootNext = 2f;

	public GameObject player;
	public int attackDamage = 2;
	public PlayerHealthScript playerHealth;

	void Start () {
		playerHealth = player.GetComponent<PlayerHealthScript> ();
		MakeInstance ();
	}

	void MakeInstance () {
		if (instance == null) {
			instance = this;
		}
	}

	void Update () {
		if(Time.time >= timeToShoot) {
			EnemyShooting ();
			timeToShoot = Time.time + timeToShootNext;
		}
	}

    public void DamageToPlayer() {
        if (playerHealth.currentHealth > 0) {
            playerHealth.TakeDamage(attackDamage);
        } else if (playerHealth.currentHealth == 0) {
            Destroy(player.gameObject);
        }
    }

	void EnemyShooting () {
		GameObject player = GameObject.Find ("Player");
		if (player != null) {
			GameObject bullet = Instantiate (enemyBullet, transform.position, transform.rotation) as GameObject;
			Vector2 direction = player.transform.position - bullet.transform.position;
			bullet.GetComponent<EnemyBulletScript> ().SetBulletDirection (direction);
		}
	}
}












