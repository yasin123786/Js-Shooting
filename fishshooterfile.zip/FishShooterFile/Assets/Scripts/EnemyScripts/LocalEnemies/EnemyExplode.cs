﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyExplode : MonoBehaviour {

	public static EnemyExplode instance;

	public int score;
	/*
	void Awake () {
		score = 0;
		MakeInstance ();
	}

	void MakeInstance () {
		if (instance == null) {
			instance = this;
		}
	}

	void OnTriggerEnter2D(Collider2D died) {
		if(died.tag == "Enemy") {
			score++;
			GameManager.instance.scoreCount (score);
			Destroy (died.gameObject);
		}
	} */
}
