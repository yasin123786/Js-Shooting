﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LocalEnemyShootScript : MonoBehaviour {

	public static LocalEnemyShootScript instance;
	public GameObject localEnemyBullet;
	private float timeToShoot = 2f;
	private float timeToShootNext = 3f;

	public GameObject player;
	public int attackDamaged = 2;
	public PlayerHealthScript playerHealth;


	void Start () {
		playerHealth = player.GetComponent<PlayerHealthScript> ();
		MakeInstance ();
	}

	void MakeInstance () {
		if (instance == null) {
			instance = this;
		}
	}

	void Update () {
		if(Time.time >= timeToShoot) {
			EnemyShooting ();
			timeToShoot = Time.time + timeToShootNext;
		}
	}

	public void DamageByAttack () {
		if (playerHealth.currentHealth > 0) {
			playerHealth.TakeDamage (attackDamaged);
		} else if (playerHealth.currentHealth == 0) {
			Destroy (player.gameObject);
			Debug.Log ("Player Died!!");
		}
	}

	void EnemyShooting () {
		GameObject player = GameObject.Find ("Player");
		if (player != null) {
			GameObject bullets = Instantiate (localEnemyBullet, transform.position, transform.rotation) as GameObject;
			Vector2 direction = player.transform.position - bullets.transform.position;
			bullets.GetComponent<LocalEnemyBulletScript> ().SetDirection (direction);
		}
	}


}
