﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyScript : MonoBehaviour {

	public static EnemyScript instance;
    public GameObject explosion;

    void Start () {

	}

	void Update () {
		if(transform.position.x < -6f) {
			Destroy (gameObject);
		}
	}

    void OnTriggerEnter2D(Collider2D target) {
        if (target.tag == "Bullet") {
            Destroy(gameObject);
            PlayerScript.instance.Score(1);
            Instantiate(explosion, transform.position, transform.rotation);
        }
    }

     
} 















