﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LocalEnemyBulletScript : MonoBehaviour {

	public static LocalEnemyBulletScript instance;
	public float bulletSpeed = 10f;
	public Vector2 direction;
	public bool isReady;


	void Awake () {
		isReady = false;
	}

	void Start () {
		MakeInstance ();
	}
	
	void MakeInstance () {
		if (instance == null) {
			instance = this;
		}
	}

	void Update () {
		if (isReady) {
			Vector2 position = transform.position;

			position += direction * bulletSpeed * Time.deltaTime;

			transform.position = position;
		}

		if(transform.position.x < -10f) {
			Destroy (gameObject);
		} else if(transform.position.x > 10f) {
			Destroy (gameObject);
		} else if (transform.position.y < -10f) {
			Destroy (gameObject);
		} else if (transform.position.y > 10f) {
			Destroy (gameObject);
		}
	}

	public void SetDirection (Vector2 bUllet) {
		direction = bUllet.normalized;
		isReady = true;
	}

	void OnTriggerEnter2D (Collider2D target) {
		if (target.tag == "Player") {
            LocalEnemyShootScript.instance.DamageByAttack();
			Debug.Log ("Player Hit!!! Local ENemy");
		}
	}
}
