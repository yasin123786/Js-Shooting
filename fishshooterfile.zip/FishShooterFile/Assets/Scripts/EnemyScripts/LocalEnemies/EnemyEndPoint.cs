﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyEndPoint : MonoBehaviour {

	public static EnemyEndPoint instance;
	public Rigidbody2D rigidBody;
	private float stopBossMove = 0f;

	void Start () {
		rigidBody = GetComponent<Rigidbody2D> ();
	}
	void OnTriggerEnter2D(Collider2D target) {
		if (target.tag == "Boss") {
			rigidBody.velocity = transform.right * stopBossMove;
			Debug.Log ("Stop");
		}
	}
}
