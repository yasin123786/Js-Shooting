﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Stage5EnemyMissile : MonoBehaviour {

    public static Stage5EnemyMissile instance;

    public float missileSpeed = 18f;
    public Vector2 direction;
    public bool isReady;


    void Awake() {
        isReady = false;    
    }


    void Start () {
		
	}

    void MakeInstance() {
        if (instance == null) {
            instance = this;
        }
    }

    void Update () {
        if (isReady) {
            Vector2 position = transform.position;

            position += direction * missileSpeed * Time.deltaTime;

            transform.position = position;
        }

        if (transform.position.x < -10f)
        {
            Destroy(gameObject);
        }
        else if (transform.position.x > 10f)
        {
            Destroy(gameObject);
        }
        else if (transform.position.y < -10f)
        {
            Destroy(gameObject);
        }
        else if (transform.position.y > 10f)
        {
            Destroy(gameObject);
        }
    }

    public void SetBulletDirection(Vector2 bUlletDirection) {
        direction = bUlletDirection.normalized;
        isReady = true;
    }

    void OnTriggerEnter2D(Collider2D target) {
        if (target.tag == "Player") {

            Stage5EnemyMissileShoot.instance.MissileDamageToPlayerStage5();

            Debug.Log("Player Hit!!!");
            Destroy(gameObject);
        }
    }
}
