﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Stage5EnemyHealth : MonoBehaviour {

    public static Stage5EnemyHealth instance;

    public int startHealth = 500;
    public int currentHealth;

    public Slider healthSlider;

    public Rigidbody2D playerEnemy;

    bool isDead;
    bool damaged;

    public GameObject explosion;
    public GameObject fireWorks;

    [SerializeField]
    public Text stageText;

	void Start () {
        currentHealth = startHealth;
        playerEnemy = GetComponent<Rigidbody2D> ();
	}
	
	
	void Update () {
		
	}

    public void TakeDamageStage5(int damageTaken) {
        damaged = true;

        currentHealth -= damageTaken;

        healthSlider.value = currentHealth;

        if (currentHealth <= 0 && !isDead) {
            Death();
        }
    }

    void Death() {
        isDead = true;
        Instantiate(explosion, transform.position, transform.rotation);
        Destroy(gameObject);
        PlayerScript.instance.Score(500);
        GameManager.instance.CompleteGame();
        stageText.gameObject.SetActive(false);
        fireWorks.SetActive(true);
    }

    private void OnTriggerEnter2D(Collider2D collision) {
        if (collision.tag == "Bullet") {
            Destroy(collision.gameObject);
            PlayerScript.instance.Score(1);
        }
    }
}
