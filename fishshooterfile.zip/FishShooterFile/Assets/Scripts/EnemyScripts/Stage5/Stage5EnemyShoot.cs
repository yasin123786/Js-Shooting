﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Stage5EnemyShoot : MonoBehaviour {

    public static Stage5EnemyShoot instance;

    public GameObject enemyBullet;

    public float timeToShoot = 0.2f;
    public float timeToShootNext = 0.5f;

    public GameObject player;
    public int damageToPlayer = 15;
    public PlayerHealthScript playerHealth;

	
	void Start () {
        playerHealth = player.GetComponent<PlayerHealthScript> ();
        MakeInstance();
	}

    void MakeInstance() {
        if (instance == null) {
            instance = this;
        }
    }

    void Update () {
        if (Time.time >= timeToShoot) {
            EnemyShooting();
            timeToShoot = Time.time + timeToShootNext;
        }
    }

    public void DamageToPlayerStage5() {
        if (playerHealth.currentHealth > 0) {
            playerHealth.TakeDamage(damageToPlayer);
        } else if (playerHealth.currentHealth == 0) {
            Destroy(player.gameObject);
        }
    }

    void EnemyShooting() {
        GameObject player = GameObject.Find("Player");
        if (player != null) {
            GameObject bullet = Instantiate(enemyBullet, transform.position, transform.rotation) as GameObject;
            Vector2 direction = player.transform.position - bullet.transform.position;
            bullet.GetComponent<Stage5EnemyBullet>().SetBulletDirection(direction);
        }
    }
}
