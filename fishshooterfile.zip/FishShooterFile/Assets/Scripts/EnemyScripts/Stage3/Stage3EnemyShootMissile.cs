﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Stage3EnemyShootMissile : MonoBehaviour {

    public static Stage3EnemyShootMissile instance;

    public GameObject missile;
    private float timeToShoot = 5f;
    private float timeToShootNext = 10f;

    public GameObject player;
    public int missileDamage = 15;
    public PlayerHealthScript playerHealth;


    void Start () {
        playerHealth = player.GetComponent<PlayerHealthScript> ();
        MakeInstance();
	}
	
	
	void Update () {
        if (Time.time >= timeToShoot) {
            ShootPlayer();
            timeToShoot = Time.time + timeToShootNext;
        }
    }

    void MakeInstance() {
        if (instance == null) {
            instance = this;
        }
    }

    public void DamagedByMissile() {
        if (playerHealth.currentHealth > 0) {
            playerHealth.TakeDamage(missileDamage);
        } else if (playerHealth.currentHealth == 0) {
            Destroy(player.gameObject);
            Debug.Log("Player Died!");
        }
    }

    void ShootPlayer() {
        GameObject player = GameObject.Find("Player");
        if (player != null) {
            GameObject bullet = Instantiate(missile, transform.position, transform.rotation) as GameObject;
            Vector2 direction = player.transform.position - bullet.transform.position;
            bullet.GetComponent<Stage3EnemyMissile>().SetBulletDirection(direction);
        }
    }
}
