﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Stage3EnemyBullet : MonoBehaviour {

    public static Stage3EnemyBullet instance;
    public float bulletSpeed = 12f;
    public Vector2 direction;
    public bool isReady;


    void Awake() {
        isReady = false;
    }


    void Start () {
        MakeInstance();
	}

    void MakeInstance() {
        if (instance == null) {
            instance = this;
        }
    }
    

    void Update () {
        if (isReady) {
            Vector2 position = transform.position;

            position += direction * bulletSpeed * Time.deltaTime;

            transform.position = position;
        }

        if (transform.position.x < -10f)
        {
            Destroy(gameObject);
        }
        else if (transform.position.x > 10f)
        {
            Destroy(gameObject);
        }
        else if (transform.position.y < -10f)
        {
            Destroy(gameObject);
        }
        else if (transform.position.y > 10f)
        {
            Destroy(gameObject);
        }
    }

    public void SetBulletDirection(Vector2 bUlletDirection) {
        direction = bUlletDirection.normalized;
        isReady = true;
    }

    void OnTriggerEnter2D(Collider2D target) {
        if (target.tag == "Player") {

            Stage3EnemyShoot.instance.DamageToPlayerStage3();
           
            Debug.Log("Player Hit!!!");
            Destroy(gameObject);

        }
    }
}
