﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Stage2EnemyHealth : MonoBehaviour {


    public static Stage2EnemyHealth instance;
    public int startHealth = 300;
    public int currentHealth;

    public Slider healthSlider;

    public Rigidbody2D playerEnemy;

    bool isDead;
    bool damaged;

    public GameObject explosion;

    [SerializeField]
    public Text stageText;

	void Start () {
        currentHealth = startHealth;
        playerEnemy = GetComponent<Rigidbody2D> ();
	}
	
	
	void Update () {
		
	}

    public void TakeDamages(int damageTaken) {
        damaged = true;

        currentHealth -= damageTaken;

        healthSlider.value = currentHealth;

        if (currentHealth <= 0 && !isDead) {
            Death();
        }

    }

    void Death() {
        isDead = true;
        Instantiate(explosion, transform.position, transform.rotation);
        Destroy(gameObject);
        PlayerScript.instance.Score(200);
        ActivateEnemy3();
    }

    void ActivateEnemy3() {
        PlayerShootScript.instance.enemyStage3.SetActive(true);
        stageText.text = "Stage 3";
    }

    private void OnTriggerEnter2D(Collider2D collision) {
        if (collision.tag == "Bullet") {
            Destroy(collision.gameObject);
            PlayerScript.instance.Score(1);
            PlayerShootScript.instance.DamageOnStage2Enemy();
        }
    }
}






















