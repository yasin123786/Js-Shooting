﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyAimWeaponScript : MonoBehaviour {

	public Transform target;
	private Quaternion newRotation;
    public float weaponAimSpeed = 5f;
    private float orientTransform;
	private float orientTarget;
	private float maxZ = -15f;
	private float minZ = 15f;

	void Start () {
		
	}
	

	void Update () {
		orientTransform = -transform.position.x;
		orientTarget = -target.position.x;

		if (orientTransform > orientTarget) {
			newRotation = Quaternion.LookRotation (transform.position - target.position, -Vector3.up);
		} else {
			newRotation = Quaternion.LookRotation (transform.position - target.position, Vector3.up);
		}

		newRotation.x = 0f;
		newRotation.y = 0f;

		transform.rotation = Quaternion.Lerp (transform.rotation, newRotation, Time.deltaTime * weaponAimSpeed);
	}
}
