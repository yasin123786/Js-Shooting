﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyGatlingScript : MonoBehaviour {

	public static EnemyGatlingScript instance; 

	public GameObject enemyBullet;
	private float timeToShoot = 0.2f;
	private float timeToShootNext = 0.5f;

	void Awake () {
		
	}


	void Update () {
		if(Time.time >= timeToShoot) {
			EnemyShooting ();
			timeToShoot = Time.time + timeToShootNext;
		}
			
	}

	void EnemyShooting () {
		GameObject player = GameObject.Find ("Player");
		if (player != null) {
			GameObject bullet = Instantiate (enemyBullet, transform.position, transform.rotation) as GameObject;
			Vector2 direction = player.transform.position - bullet.transform.position;
			bullet.GetComponent<EnemyBulletScript> ().SetBulletDirection (direction);
		}
	}

}










