﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyStage1ShootScript : MonoBehaviour {

    public static EnemyStage1ShootScript instance;

    public GameObject enemyBullet;
    private float timeToShoot = 1f;
    private float timeToShootNext = 2f;

    public GameObject player;
    public int damageToPlayer = 5;
    public PlayerHealthScript playerHealth;


	void Awake () {
        playerHealth = player.GetComponent<PlayerHealthScript>();
        MakeInstance();
	}

    void MakeInstance() {
        if (instance == null) {
            instance = this;
        }
    }


    void Update () {
        if (Time.time >= timeToShoot) {
            EnemyShooting();
            timeToShoot = Time.time + timeToShootNext;
        }
    }

    public void DamageToPlayer() {
        if (playerHealth.currentHealth > 0) {
            playerHealth.TakeDamage(damageToPlayer);
        } else if (playerHealth.currentHealth == 0) {
            Destroy(player.gameObject);
            Debug.Log("Payer Died!!!!");
        }
    }

    void EnemyShooting() {
        GameObject player = GameObject.Find("Player");
        if (player != null) {
            GameObject bullet = Instantiate(enemyBullet, transform.position, transform.rotation) as GameObject;
            Vector2 direction = player.transform.position - bullet.transform.position;
            bullet.GetComponent<EnemyStage1BulletScript>().SetBulletDirection(direction);
           // bullet.GetComponent<EnemyStage1BulletScript>().SetBulletDirection(direction);
        }
    }
}
