﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Stage1EnemyMasterHealth : MonoBehaviour {

    public static Stage1EnemyMasterHealth instance;
    public int startHealth = 250;
    public int currentHealth;
    public Slider healthSlider;

    public GameObject explosion;

    public float flashSpeed = 5f;
    public Color flashColor = new Color(1f, 0f, 0f, 0.1f);
    public Rigidbody2D playerEnemy;

    bool isDead;
    bool damaged;

    [SerializeField]
    public Text stageText;

   // public GameObject stage2EnemyActivate;

	void Awake () {
		currentHealth = startHealth;
		playerEnemy = GetComponent<Rigidbody2D> ();
	}
	
/*
	void Update () {
		if (damaged) {
			damageImage.color = flashColor;
		} else {
			damageImage.color = Color.Lerp (damageImage.color, Color.clear, flashSpeed * Time.deltaTime);
		}
		damaged = false;
	}
*/
	public void TakeDamage (int amount) {
		damaged = true;

		currentHealth -= amount;

		healthSlider.value = currentHealth;

		if (currentHealth <= 0 && !isDead) {

			Death ();
           
        }
	}

	void Death () {
		isDead = true;
        Instantiate(explosion, transform.position, transform.rotation);
        gameObject.SetActive(false);
        PlayerScript.instance.Score(100);
        ActivateStage2Enemy();
    }

    void ActivateStage2Enemy() {
        PlayerShootScript.instance.enemyStage2.SetActive(true);
        stageText.text = "Stage 2";
    }

    private void OnTriggerEnter2D(Collider2D collision) {
        if (collision.tag == "Bullet") {
            PlayerScript.instance.Score(1);
        }
    }
}
