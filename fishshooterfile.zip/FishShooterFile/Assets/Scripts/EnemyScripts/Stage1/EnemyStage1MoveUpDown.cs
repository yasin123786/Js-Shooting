﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyStage1MoveUpDown : MonoBehaviour {
	
	public static EnemyStage1MoveUpDown instance;
	private Rigidbody2D rigidBody;
	public int moveSpeed;

	private Vector3 startPosition;
	

	void Awake () {
		
	}

	void Start () {
		moveSpeed = 5;
		startPosition = transform.position;
	}

	void Update () {
		MoveVertical();
	}

	void MoveVertical () {
		transform.position = new Vector3 (transform.position.x, startPosition.y + Mathf.Sin(Time.time * moveSpeed), transform.position.z);

		if (transform.position.y > 5f) {
			transform.position = new Vector3 (transform.position.x, transform.position.y, transform.position.z);
		}
		else if (transform.position.y < -5f) {
			transform.position = new Vector3 (transform.position.x, transform.position.y, transform.position.z);
		}
	}
}
