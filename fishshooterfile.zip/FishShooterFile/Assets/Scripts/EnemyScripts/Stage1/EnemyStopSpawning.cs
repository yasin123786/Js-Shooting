﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyStopSpawning : MonoBehaviour {

	void OnCollisionEnter2D(Collision2D target) {
		if(target.gameObject.tag == "Enemy" && target.gameObject.tag == "EnemyBullet") {
			Destroy (target.gameObject);
		}
	}
}
