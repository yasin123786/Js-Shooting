﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Stage4EnemyHealth : MonoBehaviour {

    public static Stage4EnemyHealth instance;

    public int startHealth = 400;
    public int currentHealth;

    public Slider healthSlider;

    public Rigidbody2D playerEnemy;

    bool isDead;
    bool damaged;

    public GameObject explosion;

    [SerializeField]
    public Text stageText;

	void Start () {
        currentHealth = startHealth;
        playerEnemy = GetComponent<Rigidbody2D> ();
	}
	
	
	void Update () {
		
	}

    public void TakeDamageStage4(int damageTaken) {
        damaged = true;

        currentHealth -= damageTaken;

        healthSlider.value = currentHealth;

        if (currentHealth <= 0 && !isDead) {
            Death();
        }
    }

    void Death() {
        isDead = true;
        Instantiate(explosion, transform.position, transform.rotation);
        Destroy(gameObject);
        PlayerScript.instance.Score(400);
        ActivateEnemy5();
    }

    void ActivateEnemy5() {
        PlayerShootScript.instance.enemyStage5.SetActive(true);
        stageText.text = "Stage 5";
    }

    private void OnTriggerEnter2D(Collider2D collision) {
        if (collision.tag == "Bullet") {
            Destroy(collision.gameObject);
            PlayerScript.instance.Score(1);
            PlayerShootScript.instance.DamageOnStage4Enemy();
        }
    }


    /*
    private void OnTriggerEnter2D(Collider2D collision) {
        if (collision.tag == "Bullet") {
            Destroy(collision.gameObject);
            PlayerScript.instance.Score(1);
            PlayerShootScript.instance.DamageOnStage4Enemy();
        }
    } */
}
