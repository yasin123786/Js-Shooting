﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Stage4EnemyShoot : MonoBehaviour {

    public static Stage4EnemyShoot instance;

    public GameObject enemyBullet;

    public float timeToShoot = 0.3f;
    public float timeToShootNext = 1f;

    public GameObject player;
    private int damageToPlayer = 12;
    public PlayerHealthScript playerHealth;


	void Start () {
        playerHealth = player.GetComponent<PlayerHealthScript> ();
        MakeInstance();
	}
	
	
	void Update () {
        if (Time.time >= timeToShoot) {
            EnemyShooting();
            timeToShoot = Time.time + timeToShootNext;
        }
    }

    void MakeInstance() {
        if (instance == null) {
            instance = this;
        }
    }

    public void DamageToPlayerStage4() {
        if (playerHealth.currentHealth > 0) {
            playerHealth.TakeDamage(damageToPlayer);
        } else if (playerHealth.currentHealth == 0) {
            Destroy(player.gameObject);
            Debug.Log("Player Hit!!");
        }
    }

    void EnemyShooting() {
        GameObject player = GameObject.Find("Player");
        if (player != null) {
            GameObject bullet = Instantiate(enemyBullet, transform.position, transform.rotation) as GameObject;
            Vector2 direction = player.transform.position - bullet.transform.position;
            bullet.GetComponent<Stage4EnemyBullet>().SetBulletDirection(direction);
        }
    }
}
