﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraScript : MonoBehaviour {
	public static float offSetX;
	//public PlayerControllerScript player;

	//private Vector3 playerPosition;
	//public float speed = 15f;

	void Start () {
		//player = FindObjectOfType<PlayerControllerScript> ();
		//playerPosition = transform.position - player.transform.position;
	}

	void Update () {
		if(PlayerControllerScript.instance != null) {
			if (PlayerControllerScript.instance.isAlive) {
				MoveCamera ();
			}
		}
	}

	void MoveCamera () {
		Vector3 temp = transform.position;
//		temp.x = PlayerControllerScript.instance.GetPositionX () + offSetX;
		transform.position = temp;
	}

	/*
	void Update () {
		distance = player.transform.position.x - playerPosition.x;
		transform.position = new Vector3 (transform.position.x + distance, transform.position.y, transform.position.z);
		playerPosition = player.transform.position;
	} */
}
