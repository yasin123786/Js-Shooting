﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerShooting : MonoBehaviour {

    public static PlayerShooting instance;
    //Player Bullet
    [SerializeField]
    public Button fireButton;

    public GameObject bullet;
    public Transform bulletSpawn;

    public float fireRate;
    private float nextFire = 0.75f;

    public AudioSource audioSource;
    public AudioClip firingclip, missileClip;

    //Player Missile
    public GameObject missile;

    [SerializeField]
    public Button fireMissile;
    public Transform missileSpawn;
    
    public float missileRate;
    private float nextFireMissile = 0.75f;

    public Text missileLeft;
    int missile_ammo;

	void Start () {
        MakeInstance();
        missile_ammo = 5;
        missileLeft.text = "Missile : " + missile_ammo;
    }

    void MakeInstance() {
        if (instance == null)
        {
            instance = this;
        }
    }

    public void Firing () {
		if(fireButton && Time.time >= nextFire) {
			nextFire = Time.time + fireRate;
			Instantiate (bullet, bulletSpawn.position, bulletSpawn.rotation);
            audioSource.PlayOneShot(firingclip);
       }
	}

    public void FireMissile() {
        if (fireMissile && Time.time >= nextFireMissile) {
            nextFireMissile = Time.time + missileRate;
            Instantiate(missile, missileSpawn.position, missileSpawn.rotation);
            audioSource.PlayOneShot(missileClip);
            missile_ammo -= 1;
            missileLeft.text = "Missile : " + missile_ammo;
        }

        if (missile_ammo == 0) {
            fireMissile.gameObject.SetActive(false);
        } 
    }

    public void MissileAdd(int addmissiles) {
        missile_ammo += addmissiles;

        missileLeft.text = "Missile : " + missile_ammo;

        if (missile_ammo > 0) {
            fireMissile.gameObject.SetActive(true);
        }
        
    } 
}







