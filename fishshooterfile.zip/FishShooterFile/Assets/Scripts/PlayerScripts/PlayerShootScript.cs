﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerShootScript : MonoBehaviour {

	public static PlayerShootScript instance;

    //Stage 1
	public GameObject enemyStage1;
	public int attackDamage = 10;
	public Stage1EnemyMasterHealth enemyHealth;

    //Stage 2
    public GameObject enemyStage2;
    public int damageToEnemyStage2 = 10;
    public Stage2EnemyHealth stage2Health;

    //Stage 3
    public GameObject enemyStage3;
    public int damageToEnemyStage3 = 10;
    public Stage3EnemyHealth stage3Health;

    //Stage 4
    public GameObject enemyStage4;
    public int damageToEnemyStage4 = 10;
    public Stage4EnemyHealth stage4Health;

    //Stage 5
    public GameObject enemyStage5;
    public int damageToEnemyStage5 = 10;
    public Stage5EnemyHealth stage5Health;

	void Awake () {
		enemyHealth = enemyStage1.GetComponent<Stage1EnemyMasterHealth> ();
        stage2Health = enemyStage2.GetComponent<Stage2EnemyHealth> ();
        stage3Health = enemyStage3.GetComponent<Stage3EnemyHealth> ();
        stage4Health = enemyStage4.GetComponent<Stage4EnemyHealth> ();
        stage5Health = enemyStage5.GetComponent<Stage5EnemyHealth> ();
       	MakeInstance ();
        enemyStage2.SetActive(false);
        enemyStage3.SetActive(false);
        enemyStage4.SetActive(false);
        enemyStage5.SetActive(false);
	}
	
	void MakeInstance () {
		if (instance == null) {
			instance = this;
		}
	}

	public void AttackDamage () {
		if (enemyHealth.currentHealth > 0) {
			enemyHealth.TakeDamage (attackDamage);
		} else if (enemyHealth.currentHealth == 0) {
			Destroy (enemyStage1.gameObject);
			Debug.Log ("Enemy Died!!!!");
       }
	}

    public void DamageOnStage2Enemy() {
        if (stage2Health.currentHealth > 0) {
            stage2Health.TakeDamages(damageToEnemyStage2);
        } else if (stage2Health.currentHealth == 0) {
            Destroy(enemyStage2.gameObject);
        }
    }

    public void DamageOnStage3Enemy() {
        if (stage3Health.currentHealth > 0) {
            stage3Health.TakeDamageStage3(damageToEnemyStage3);
        } else if (stage3Health.currentHealth == 0) {
            Destroy(enemyStage3.gameObject);
        }
    }

    public void DamageOnStage4Enemy() {
        if (stage4Health.currentHealth > 0) {
            stage4Health.TakeDamageStage4(damageToEnemyStage4);
        } else if (stage4Health.currentHealth == 0) {
            Destroy(enemyStage4.gameObject);
        }
    }

    public void DamageOnStage5Enemy() {
        if (stage5Health.currentHealth > 0) {
            stage5Health.TakeDamageStage5(damageToEnemyStage5);
        } else if (stage5Health.currentHealth == 0) {
            Destroy(enemyStage5.gameObject);
        }
    }

}




















