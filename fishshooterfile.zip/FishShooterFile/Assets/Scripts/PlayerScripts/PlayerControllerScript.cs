﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityStandardAssets.CrossPlatformInput;

[System.Serializable]
public class SetPlayerBoundary {
	public float Xmax, Xmin, Ymax, Ymin;
}

public class PlayerControllerScript : MonoBehaviour {

	public static PlayerControllerScript instance;

	public SetPlayerBoundary boundary;
	private Rigidbody2D rigidbody;
	public float speed;

	public Animator anim;

	public bool isAlive;

	void Start () {
		rigidbody = GetComponent<Rigidbody2D> ();

		if(instance == null)
		{
			instance = this;
		}
		isAlive = true;
		
	}
	/*
	void Update () {
		if(Input.GetButton("Fire1") && Time.time > nextFire) {
			nextFire = Time.time + fireRate;
			Instantiate (bullet, bulletSpawn.position, bulletSpawn.rotation);
			anim.SetTrigger ("Shoot");
		}
	}
	*/
	void FixedUpdate () {
		if (isAlive) {

			Vector2 moveJoystick = new Vector2 (CrossPlatformInputManager.GetAxis("Horizontal"), CrossPlatformInputManager.GetAxis("Vertical")) * speed;
			rigidbody.AddForce (moveJoystick * speed);
            // /*
            float movePlayerHorizontal = Input.GetAxis ("Horizontal");
			float movePlayerVertical = Input.GetAxis ("Vertical");
			Vector3 movement = new Vector3 (movePlayerHorizontal, movePlayerVertical, 0.0f);
			rigidbody.velocity = movement * speed;
            //*/
            
            rigidbody.position = new Vector3 (Mathf.Clamp (rigidbody.position.x, boundary.Xmin, boundary.Xmax),
				Mathf.Clamp (rigidbody.position.y, boundary.Ymin, boundary.Ymax), 0.0f);
		}
	}

}






























