﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerScript : MonoBehaviour {

    public static PlayerScript instance;

    [SerializeField]
    public Text scoreText;
    
    public int score;
    

    void Awake () {
        MakeInstance();
    }


    void Update() {

    }

    void MakeInstance() {
        if (instance == null) {
            instance = this;
        }
    }

    public void Score(int score) {
        this.score += score;
        scoreText.text = "Score : " + this.score;
        GameManager.instance.scoreCount(this.score);
        GameManager.instance.IfPlayerDied(this.score);
    }

}























