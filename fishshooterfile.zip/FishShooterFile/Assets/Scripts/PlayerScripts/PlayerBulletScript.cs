﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerBulletScript : MonoBehaviour {

	public static PlayerBulletScript instance;
	public float bulletSpeed = 10f;
	public Vector2 direction;
	public bool isReady;

	void Awake () {
		isReady = false;
	}
	
	void Start () {
		MakeInstance ();
	}

	void MakeInstance () {
		if (instance == null) {
			instance = this;
		}
	}

	void Update () {
		
	}
}
