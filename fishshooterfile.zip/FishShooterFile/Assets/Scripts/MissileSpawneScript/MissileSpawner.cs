﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MissileSpawner : MonoBehaviour {

    public GameObject missile;

    private float timeToSpawn = 15f;
    private float timeToSpawnNext = 30f;

    void Start () {
		
	}
	
	
	void Update () {
        if (Time.time >= timeToSpawn) {
            SpawnMissileCrate();
            timeToSpawn = Time.time + timeToSpawnNext;
        }
    }

    void SpawnMissileCrate() {
        Vector3 spawnMissile = new Vector3(Random.Range(-2f, 0f), Random.Range(-2f, 3f), transform.position.z);
        transform.position = spawnMissile;
        GameObject.Instantiate(missile, spawnMissile, transform.rotation);
    }
}







