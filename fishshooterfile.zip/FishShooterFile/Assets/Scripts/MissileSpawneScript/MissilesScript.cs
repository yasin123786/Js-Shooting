﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MissilesScript : MonoBehaviour {

    public static MissilesScript instance;

    public AudioClip missileClip;

    public GameObject player;
    public int missile_ammo = 5;
    public PlayerShooting ammo;

	// Use this for initialization
	void Start () {
        ammo = player.GetComponent<PlayerShooting>();
        MakeInstance();
	}

    void MakeInstance() {
        if (instance == null)
        {
            instance = this;
        }
    }

    private void OnTriggerEnter2D(Collider2D collision) {
        if (collision.tag == "Player") {
            PlayerShooting.instance.MissileAdd(missile_ammo);
            PlayerShooting.instance.audioSource.PlayOneShot(missileClip);
            Destroy(gameObject);
        }
    } 
}











