﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour {

	public static GameManager instance;

    public GameObject pausePanel, completeGamePanel;

	[SerializeField]
	public Text scoreText,highScoreText,scoreComplete, pauseText, gameOverText;

    [SerializeField]
    public Button resumeButton, playAgainButton;

	void Awake () {
		MakeInstance ();
        Time.timeScale = 1f;    
	}

	void MakeInstance () {
		if (instance == null) {
			instance = this;
		}
	}
	

	void Update () {
		
	}

    public void PauseGame() {
        Time.timeScale = 0f;
        pausePanel.SetActive(true);
        pauseText.gameObject.SetActive(true);
        gameOverText.gameObject.SetActive(false);
        resumeButton.gameObject.SetActive(true);
        playAgainButton.gameObject.SetActive(false);
    }

    public void ResumeGame() {
        Time.timeScale = 1f;
        pausePanel.SetActive(false);
    }

    public void PlayAgain() {
        SceneManager.LoadScene("GameplayScene");
    }

    public void CompleteGame() {
        completeGamePanel.SetActive(true);
        scoreComplete.text = "Score : " + scoreText;
    }

	public void scoreCount (int score) {
		scoreText.text = "Score: " + score;
	}

    public void GameOver() {
        pausePanel.SetActive(true);
        gameOverText.gameObject.SetActive(true);
        pauseText.gameObject.SetActive(false);
        highScoreText.text = "High SCore: " + ScoreScript.instance.GetHighScore();
        playAgainButton.gameObject.SetActive(true);
        resumeButton.gameObject.SetActive(false);
    }

    public void MainMenu() {
        SceneManager.LoadScene("Main");
    }

    public void IfPlayerDied(int diedSCore) {
        highScoreText.text = "High Score: " + PlayerScript.instance.score;

        if (diedSCore > ScoreScript.instance.GetHighScore()) {
            ScoreScript.instance.SetHighScore(diedSCore);
        }

        highScoreText.text = "High SCore: " + ScoreScript.instance.GetHighScore();
    }
}










