﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawner : MonoBehaviour {

	public GameObject Enemy;
	public GameObject Enemy1;
	public Vector3 spawnEnemy;
	public int EnemyCount;
	public float spawnTime, startTime, waveTime;

	void Start () {
		StartCoroutine (SpawnEnemies());
	}
	
	IEnumerator SpawnEnemies () {
		yield return new WaitForSeconds (startTime);
		while(true) {
			for(int i = 0; i < EnemyCount; i++ ) {
				Vector3 spawnPosition = new Vector3 (-spawnEnemy.x, Random.Range(-spawnEnemy.y, spawnEnemy.y), spawnEnemy.z);
				Quaternion spawnRotation = Quaternion.identity;
				int randomNumber = Random.Range (0,2);

				switch(randomNumber) {

				case 0:
					Instantiate (Enemy, spawnPosition, spawnRotation);
					break;

				case 1: Instantiate (Enemy1, spawnPosition, spawnRotation);
					break;
				}

				yield return new WaitForSeconds (spawnTime);
			}
			yield return new WaitForSeconds (waveTime);
		}
	}
}
